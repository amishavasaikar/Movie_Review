import React from 'react';

export const Customer= () => {
     return(
        <div>
            This is Customer Page
        </div>
     )
}

export default Customer;