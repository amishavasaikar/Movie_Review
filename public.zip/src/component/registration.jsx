import React, { useState } from 'react';
import '../App.css';

export const Registration = () => {

    const [email,setEmail]= useState("");
    const [password,setPassword]= useState("");
    const [name ,setName] = useState("");

    const [allEntry,setAllEntry]=useState([]);

    const submitForm = (e)=>{
        
        e.preventDefault();
        if(name && email && password)
        {
            const newEntry ={name : name ,email : email ,password: password}

            setAllEntry([...allEntry,newEntry]);
            console.log(allEntry);
            setEmail("");
            setPassword("");
            setName("");
        }
        else{
            alert("Please Enter name,email and password");
        }
        
    }
     return(
        <div className='signin-form'>
           

            <form action='' onSubmit={submitForm}>
            <div className="form-group">
                 <label for="exampleInputEmail1">Name</label>
                 <input type="text" class="form-control" id="exampleInputName" autoComplete='off' aria-describedby="emailHelp" placeholder="Enter your Name"
                    value={name}
                    onChange={(e)=> setName(e.target.value)}
                 />
                 
                </div>
                <div className="form-group">
                 <label for="exampleInputEmail1">Email address</label>
                 <input type="email" class="form-control" id="exampleInputEmail1" autoComplete='off' aria-describedby="emailHelp" placeholder="Enter your email"
                    value={email}
                    onChange={(e)=> setEmail(e.target.value)}
                 />
                 
                </div>
                <div className="form-group">
                  <label for="exampleInputPassword1">Password</label>
                  <input type="password" class="form-control" id="exampleInputPassword1" autoComplete='off' placeholder="Password"
                   value={password}
                   onChange={(e)=> setPassword(e.target.value)}/>
                </div>
                
                
                <button type="submit" class="btn-signin btn btn-primary " data-toggle="button"  onClick={submitForm}>Register</button>
            </form>
            <div>
                {
                    allEntry.map((curElement,key) =>{
                        return(
                            <div>
                                <p>You have Registered successfully</p>
                            </div>
                        )
                    })
                }
            </div>
            
        </div>
     )
}

export default Registration;