import React, { useState } from 'react';
import '../App.css';
import './signin.css';

export const Signin= () => {

    const [email,setEmail]= useState("");
    const [password,setPassword]= useState("");

    const [allEntry,setAllEntry]=useState([]);


    

    const submitForm = (e)=>{
            e.preventDefault();
        if(email && password)
        {
            const newEntry ={email : email ,password: password}

            setAllEntry([...allEntry,newEntry]);       
                
            console.log(allEntry);
            console.log("you have signIn successfully");
            setEmail("");
            setPassword("");
        }
       else{
        alert("Please Enter email and password")
       }
       
    }


    
     return(
       
        <div className='signin-form'>

            <form action='' onSubmit={submitForm}>
                <div className="form-group">
                 <label for="exampleInputEmail1">Email address</label>
                 <input type="email" class="form-control" id="exampleInputEmail1" autoComplete='off' aria-describedby="emailHelp" placeholder="Enter your email"
                    value={email}
                    onChange={(e)=> setEmail(e.target.value)}
                 />
                 
               
               
                  <label for="exampleInputPassword1">Password</label>
                  <input type="password" class="form-control" id="exampleInputPassword1" autoComplete='off' placeholder="Password"
                   value={password}
                   onChange={(e)=> setPassword(e.target.value)}/>
                
                
              
                <button type="submit" class="btn-signin btn btn-primary " data-toggle="button" onClick={submitForm}>Login</button>
                </div>
            </form>
            <div>
                {
                    allEntry.map((curElement,key) =>{
                        return(
                            <div>
                                <p>You have signin successfully</p>
                            </div>
                        )
                    })
                }
            </div>
        </div>
     )
}

export default Signin;